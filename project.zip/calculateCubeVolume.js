//Write a program to *calculate* the **volume** of a **cube**. Start with a variable that contains the **length** of 1 edge in meters.

function calculateCubeVolume (length){
    return length ** 3;
}

export {calculateCubeVolume}